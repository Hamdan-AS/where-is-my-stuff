# Where Is My Stuff? - final SRS (version 1.0)

This folder contains the 52-page PDF compiled from the accompanying LaTeX source with XeLaTeX (TeX Live 2026). The source is a complete document; the application repository is not required to compile it.

## Add your cover details

Edit `SRS-Where-Is-My-Stuff.tex` near the top:

- Replace the rules in `\GroupName` and `\SubmissionDate` with your group and submission date.
- Replace the four blank rows in the title-page student table with names and roll numbers.
- Optionally replace `pdfauthor={Project team}` in the PDF metadata.

These fields were deliberately left for the project team. All technical sections are completed.

## Compile

Use **XeLaTeX**, not pdfLaTeX. From this folder, run:

```text
xelatex -interaction=nonstopmode -halt-on-error SRS-Where-Is-My-Stuff.tex
xelatex -interaction=nonstopmode -halt-on-error SRS-Where-Is-My-Stuff.tex
xelatex -interaction=nonstopmode -halt-on-error SRS-Where-Is-My-Stuff.tex
```

On Windows, `compile.ps1` runs these passes and checks the compiler exit status. An isolated local compiler is also available in this project's `tmp/tools/tinytex/TinyTeX/bin/windows/xelatex.exe`; pass its absolute path with `-XeLaTeX` if it is not on PATH.

For Overleaf, upload the LaTeX ZIP, select XeLaTeX and set this `.tex` file as the main document. Arial is used when installed; TeX Gyre Heros is the fallback. Keep the `assets` directory beside the source.

## Scope and evidence

- Course structure: five chapters plus data dictionary, traceability, UI wireframes and interface-evidence appendices.
- 68 functional requirements, acceptance criteria, five proposed performance targets, safety/security and quality requirements.
- Context, deployment, use case, report state, match state, publication sequence and entity-relationship diagrams.
- Localhost workflow screenshots captured with Playwright using synthetic data in an isolated SQLite database.
- Live registration/login screenshots and dated public deployment observations for https://lost-and-found.54.252.227.103.sslip.io/register/, inspected on 10 October 2026.
- Live HTTPS/TLS, DNS, response headers, anonymous redirects and account form fields documented in the operating environment and Appendix D. No live account or report was created.
- Known implementation limitations are explicit. Proposed targets and acceptance scenarios are not represented as passing test results.
- Reviewed source baseline: repository `77b600e`, inspected 10 October 2026. No application source or original database changes were made for this SRS. Public UI observations support correspondence with this project; the deployed backend commit and live database engine were not independently identified.

The older Markdown documents are source references. The delivered version 1.0 PDF and `.tex` supersede the earlier formatted copies. For programmatic regeneration from the reviewed source, use `scripts/build_srs_final.py`; regenerating will reset manual edits to the generated `.tex`. Do not use the older `build_srs_tex.py` to recreate this edition.
