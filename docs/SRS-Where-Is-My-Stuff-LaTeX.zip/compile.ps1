param([string]$XeLaTeX = 'xelatex')
$ErrorActionPreference = 'Stop'
Push-Location -LiteralPath $PSScriptRoot
try {
    for ($pass = 1; $pass -le 3; $pass++) {
        & $XeLaTeX -interaction=nonstopmode -halt-on-error 'SRS-Where-Is-My-Stuff.tex'
        if ($LASTEXITCODE -ne 0) { throw "XeLaTeX failed on pass $pass." }
    }
} finally {
    Pop-Location
}
